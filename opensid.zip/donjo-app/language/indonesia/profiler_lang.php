<?php

$lang['profiler_database']		= 'BASIS DATA';
$lang['profiler_controller_info'] = 'KELAS/METODE';
$lang['profiler_benchmarks']	= 'TOLOK UKUR';
$lang['profiler_queries']		= 'KUERI';
$lang['profiler_get_data']		= 'DATA GET';
$lang['profiler_post_data']		= 'DATA POST';
$lang['profiler_uri_string']	= 'STRING URI';
$lang['profiler_memory_usage']	= 'PENGGUNAAN MEMORI';
$lang['profiler_config']		= 'VARIABEL KONFIG';
$lang['profiler_session_data']	= 'DATA SESI';
$lang['profiler_headers']		= 'HTTP HEADERS';
$lang['profiler_no_db']			= 'Driver basis data saat ini tidak dimuat';
$lang['profiler_no_queries']	= 'Tidak ada kueri yang dijalankan';
$lang['profiler_no_post']		= 'Tidak ada data POST';
$lang['profiler_no_get']		= 'Tidak ada data GET';
$lang['profiler_no_uri']		= 'Tidak ada data URI';
$lang['profiler_no_memory']		= 'Penggunaan Memori Tidak Tersedia';
$lang['profiler_no_profiles']	= 'Tidak ada Data Profil - semua bagian Profiler telah dinonaktifkan.';
$lang['profiler_section_hide']	= 'Sembunyi';
$lang['profiler_section_show']	= 'Tampil';
