<?php

$lang['migration_none_found'] = "Tidak ada migrasi yang ditemukan.";
$lang['migration_not_found'] = "Migrasi ini tidak ditemukan.";
$lang['migration_multiple_version']	= "Terdapat beberapa migrasi dengan nomor yang sama: %d.";
$lang['migration_class_doesnt_exist'] = "Kelas migrasi \"%s\" tidak dapat ditemukan.";
$lang['migration_missing_up_method'] = "Kelas migrasi \"%s\" kehilangan metode 'up'";
$lang['migration_missing_down_method'] = "Kelas migrasi \"%s\" kehilangan metode 'down'";
$lang['migration_invalid_filename'] = "Migrasi \"%s\" memiliki nama berkas yang tidak sah.";
